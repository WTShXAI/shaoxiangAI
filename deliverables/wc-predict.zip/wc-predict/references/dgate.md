# D-Gate v5.2.4

## Layers
1. **Mode C** (≥70%): hcp<1.75→1.8×/0.14, hcp≥1.75→1.4×/0.45
2. **Mode C-away** (>65% away): 2.0×/0.14
3. **Mode A** (48-70%): spread-based/0.28
4. **Mode B** (spread<0.15,ou≤2.75): 1.20×/0.44
5. **Default**: 0.32

## v5.2.4 Fix
Huge favorites (hcp≥1.75): d_boost 2.2→1.4, threshold 0.14→0.45
Root cause: single-match draw noise inflates team style tags.

## Signals
- cs_other < 5.0 → veto draw
- S7: ou/max(abs(hcp),0.25) ≥ threshold → ×0.70
- Team styles: 沉闷型×1.03, 互捅型×0.88
