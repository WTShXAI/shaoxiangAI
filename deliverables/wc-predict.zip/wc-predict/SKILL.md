---
name: wc-predict
description: |
  WC2026 World Cup prediction. D-Gate v5.2.4 + FIFA Elo + cs_other + Poisson λ.
  Outputs match verdicts (主胜/客胜/平局/屠杀) with primary + secondary score picks.
  Auto-saves to predictions_log. Use when user asks "predict tomorrow", "比分推荐", "预测".
agent_created: true
---

# WC2026 Predict

## Quick Start

```bash
cd D:/Architecture/v4.0
python .workbuddy/skills/wc-predict/scripts/predict.py 2026-06-25 --db
```

Options: `--json` (machine output), `--no-save` (skip DB), `all` (all future).

## Output Format

```
比赛             | D-Gate | 首选   | 次选
挪威vs塞内加尔    | 主胜   | 2-1   | 1-0
法国vs伊拉克      | 屠杀   | 3-0   | 2-0
```

- `主胜/客胜` = home/away win, `平局` = draw, `屠杀` = blowout (cs_other < 5.0)
- 首选/次选 = top 2 scores in predicted direction

## Data

| File | Purpose |
|------|---------|
| `rules/d_gate_v52.py` | D-Gate v5.2.4 engine |
| `config/fifa_rankings_2026.json` | 46-team FIFA rankings |
| `data/wc2026_timeline.db` | Schedule + odds + predictions_log |
